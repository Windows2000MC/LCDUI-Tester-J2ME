This is a source code zip of 'LCDUI Tester' java application.

This zip contains .java source code files and resources, as well as includes all compiled and perverified class files.

If you want to modify the source code on J2ME SDK Mobile on your java phone, make sure your java phone have aleast 1536KB (1.5MB) or more java heap memory and a mid-range chipset [e.g. MediaTek MT6260] to compile this app with modifications seamlessly. but if your java phone doesn't meet up the minimum reqirements, you will end up compiling this in too much time and have a chance to crashing this app with 'Out of Memory' error.
 
The java application and the source code zip file are protected under MIT Licence. This is a free software; you can redistrubute it and/or modify it as long as you keep the original author's name and the program itself under the terms of MIT Licence.

Thank you for reading!

Tanvir Islam
Windows2000MC

6/11/2026 | 21:33PM [Bangladesh Standard Time]
Created and Written on MiniCommander J2ME on Symphony D54+ 